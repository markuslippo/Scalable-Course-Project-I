# Designing and Building Scalable Web Applications / Course Project I

This application is a Python programming application where the user gets programming assignments and writes a Python program to solve the assignment.

