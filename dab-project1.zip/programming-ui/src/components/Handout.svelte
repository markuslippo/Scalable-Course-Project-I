<script>  
  import { assignment } from '../stores/stores.js';
</script>
  
<div class="mt-10 ">
  <h1 class="text-white font-extrabold text-4xl sm:text-5xl lg:text-6xl tracking-tight text-center"> {$assignment.title}</h1>
  <p class="text-slate-400 mt-6 text-lg tracking-tight font-normal text-center">{$assignment.handout}</p>
</div>

  