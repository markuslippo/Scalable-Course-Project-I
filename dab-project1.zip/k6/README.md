# This folder contains the k6 tests for the application
